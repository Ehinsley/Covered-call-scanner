# Options Scanner — ETF / Stock Selector

This release adds a security-type selector while preserving covered-call, cash-secured-put, trend, probability, profit and resumable-batch reports.

## What is new

- **Securities to scan**: `All securities`, `ETFs only`, or `Stocks only`.
- `ETFs only` checks Nasdaq Trader's official ETF flags before adding online-discovered symbols; if the free directory cannot load, the app limits the ETF search to a curated list of known ETF symbols instead of mixing stocks into the report.
- Optional **Include leveraged/inverse ETFs (high risk)** checkbox appears in ETF mode; default off. This may include high-volatility ETFs such as HIMZ when enabled and listed.
- New `Security type` column in trade and stock-movement reports and downloadable CSVs.
- Works with the 20–500 security queue and **Scan next batch / Continue**.
- Existing 16-field progress checkpoints can still load; new checkpoints save the security-type setting.

## Update existing Streamlit app from your Android phone

1. Download `app.py` separately, or extract it from the ZIP.
2. Open https://github.com/Ehinsley/Covered-call-scanner and replace **the existing `app.py` at the repository root**; commit the change.
3. Wait for Streamlit Community Cloud to redeploy your existing scanner, then refresh the app.
4. Under **Account, risk, and scan settings**, choose `ETFs only` from **Securities to scan**. Keep leveraged ETFs unchecked unless you intentionally want their additional risks.
5. Tap **Start new scan** to apply this filter. **Scan next batch / Continue** continues the previous scan if one was already started, so the new filter won't affect an existing batch queue.

No additional Python dependencies, API tokens, or paid subscription are required for the new filter.

## Limitations

- Nasdaq Trader listing directories and free option quote services may be blocked, delayed or inaccessible on Streamlit Cloud. If ETF listing retrieval fails, only the built-in ETF starting list is used. Results are not a guaranteed complete scan of all listed ETFs.
- Being listed as an ETF does **not** guarantee listed options, sufficient liquidity, affordable collateral or a profitable trade.
- Quote sources and delays are unchanged. Always verify prices, contract deliverables and buying power in Webull before trading.
- Tests cover parsing, ETF-only and stock-only filtering, leveraged fund inclusion/exclusion, fallback behavior, 500 symbols, and checkpoint field compatibility. Live remote access cannot be verified in the build environment.
